const mongoose = require('mongoose');

// Schema
const bookSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        minLength: 3,
        maxLength: 300
    },
    author: {
        type: String,
        required: true,
        minLength: 10,
        maxLength: 400
    },
    categories: {
        type: [String],
        required: true,
        enum: ['sf', 'fantasy', 'polar', 'thriller', 'novel', 'marketing', 'business', 'non-fiction', 'fiction']
    },
    stock: {
        type: Number,
        default: 0,
        min: 0
    },
    publishDate: {
        type: Date,
        default: new Date()
    },
    isBestSeller: {
        type: Boolean,
        required: false,
        default: false
    }
});

//Model
const Book = mongoose.model('Book', bookSchema);

//Export
module.exports = Book;