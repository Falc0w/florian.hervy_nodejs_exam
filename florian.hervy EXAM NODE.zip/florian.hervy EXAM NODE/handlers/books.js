const db = require('../models');

//Create a book
exports.createBook = async (req, res) => {
    try {
        let newBook = await db.Book.create(req.body);
        console.log(newBook);
        return res.status(200).json({
            message: 'Nouveau livre créée avec succès !',
            newBook
        });
    } catch (err) {
        return res.status(400).json({
            message: 'Oups! On a pas pu créer ton livre',
            error: err
        });
    }
};

//Get all books
exports.readAllBooks = async (req, res) => {
    try {
        let books = await db.Book.find();
        return res.status(200).json(books);
    } catch (err) {
        return res.status(400).json({
            message: 'Oups! Could not find your books',
            error: err
        });
    }
};

//Get one book
exports.readOneBook= async (req, res) => {
    try {
        let thisBook = await db.Book.findById(req.params.id);
        return res.status(200).json(thisBook);
    } catch (err) {
        return res.status(400).json({
            message: 'Oups! Could not find your books',
            error: err
        });
    }
};

//Get one book
exports.readOneBook= async (req, res) => {
    try {
        let thisBook = await db.Book.findById(req.params.id);
        return res.status(200).json(thisBook);
    } catch (err) {
        return res.status(400).json({
            message: 'Oups! Could not find your books',
            error: err
        });
    }
};

//Update one book
exports.updateOneBook = async (req, res) => {
    try {
        let booktoUpdate = await db.Book.findByIdAndUpdate(
            req.params.id,
            {
                $set: req.body
            },
            { new: true }
        );
        return res.status(200).json({
            message: 'Youpi book bien modifiée!',
            booktoUpdate
        });
    } catch (err) {
        return res.status(400).json({
            message: 'Oups! Could not modify your books',
            error: err
        });
    }
};

//Delete one book
exports.deleteOneBook = async (req, res) => {
    try {
        await db.Book.findByIdAndRemove(req.params.id);
        return res.status(200).json('Book deleted !');
    } catch (err) {
        return res.status(400).json({
            message: 'Oups! OCould not delete your books',
            error: err
        });
    }
};